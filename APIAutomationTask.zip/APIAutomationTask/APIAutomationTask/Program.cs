﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace APIAutomationTask
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> listOfFirstName = new List<string>();
            for (int i = 0; i < 5; i++) {
                string first = getFirstName();
                listOfFirstName.Add(first);
            }

            for (int i = 0; i < listOfFirstName.Count; i++) {
                JObject jsonObject =  APIExecutor("https://api.agify.io/?name="+ listOfFirstName[i]);
                Console.WriteLine(jsonObject);
                jsonObject = APIExecutor("https://api.genderize.io/?name=" + listOfFirstName[i]);
                Console.WriteLine(jsonObject);
                jsonObject = APIExecutor("https://api.nationalize.io/?name=" + listOfFirstName[i]);
                Console.WriteLine(jsonObject);
            }
            
        }

        static public string getFirstName()
        {
            JObject jsonObject = APIExecutor("https://randomuser.me/api/");
            return (string)jsonObject["results"][0]["name"]["first"];
        }

        static private JObject APIExecutor(string url)
        {
            //Task<string> contentJson = getJSONResponse("https://randomuser.me/api/");
            string contentJson = GetReleases(url);
            JObject rss = JObject.Parse(contentJson);
            return rss;
        }

        static private string GetReleases(string url)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string response = client.GetStringAsync(new Uri(url)).Result;
                return response;
            }
        }

        
    }
}
