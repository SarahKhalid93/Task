﻿using Nancy.Json;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using UIAutomationTasks.UIAutomationTasks;

namespace UIAutomationTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            Test1();
        }

       static public void Test1()
        {
           

            Task1 task1 = new Task1();
            task1.openChromeBrowser();
            task1.setSearchArea("Toronto");
            task1.clickSearchButton();
            
            foreach(int price in task1.getlistOfPrices())
            {
                Console.WriteLine("£" + price);
            }
            task1.selectProperty();
            task1.clickOnViewDescription();

            String json = ToJSONRepresentation(task1.getRoomDetails());
            File.WriteAllText(@"D:\"+ task1.getStreetName() + ".json", json);
            task1.closeChrome();



        }

        public static String ToJSONRepresentation(List<Rooms> roomsList)
        {
            StringBuilder sb = new StringBuilder();
            JsonWriter jw = new JsonTextWriter(new StringWriter(sb));

            jw.Formatting = Formatting.Indented;

            int i;
            i = 0;

            for (i = 0; i < roomsList.Count; i++)
            {
                jw.WriteStartObject();
                jw.WritePropertyName("NameSize");
                jw.WriteValue(roomsList[i].getName());
                jw.WritePropertyName("Feature");
                jw.WriteValue(roomsList[i].getFeature());
                jw.WriteEndObject();
            }



            return sb.ToString();
        }

    }
}
