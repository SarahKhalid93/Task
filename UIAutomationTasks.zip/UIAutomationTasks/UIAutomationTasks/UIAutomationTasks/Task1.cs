﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;

namespace UIAutomationTasks.UIAutomationTasks
{
    class Task1
    {
        
        private IWebDriver webDriver;



        public void openChromeBrowser()

        {
            this.webDriver = new ChromeDriver();
            webDriver.Manage().Window.Maximize();
            webDriver.Navigate().GoToUrl("https://www.zoopla.co.uk/");
        }

        public void setSearchArea(string area)
        {
            IWebElement webElement = webDriver.FindElement(By.Id("header-location"));
            webElement.SendKeys(area);
            Thread.Sleep(2000);
            IList<IWebElement> listOfAreas = webDriver.FindElements(By.XPath("//ul[@data-testid='autosuggest-list']/li"));
            listOfAreas[0].Click();

        }

        public void clickSearchButton()
        {
            IWebElement webElement = webDriver.FindElement(By.XPath("//button[@data-testid='search-button']"));
            webElement.Click();
            Thread.Sleep(5000);
        }

        public List<int> getlistOfPrices()
        {
            IList<IWebElement> listOfPrices = webDriver.FindElements(By.XPath("//div[contains(@class,'-ListingsContainer ')]/div[starts-with(@data-testid,'extended-search-result_listing')]//div[@data-testid='listing-price']/p[starts-with(text(),'£')]"));
            List<int> pricesList = new List<int>();

            foreach (IWebElement webElement in listOfPrices)
            {
                pricesList.Add(int.Parse( webElement.Text.Split("£")[1].Replace(",","")));

            }
            List<int> sortPricesList = pricesList.OrderByDescending(price => price).ToList();
            return sortPricesList;       
        }

        public void selectProperty()
        {
            IList<IWebElement> listOfProperties = webDriver.FindElements(By.XPath("//div[contains(@class,'-ListingsContainer ')]/div[starts-with(@data-testid,'extended-search-result_listing')]"));
            listOfProperties[4].Click();
        }

        public void clickOnViewDescription()
        {
            IWebElement webElement = webDriver.FindElement(By.XPath("//button[contains(@class,'-Button-ButtonWithIcon-ToggleButton')]"));
            webElement.Click();
            Thread.Sleep(2000);
        }
        public List<Rooms> getRoomDetails()
        {///following-sibling::br
            List<Rooms> roomSize = new List<Rooms>();
            IList<IWebElement> webElements = webDriver.FindElements(By.XPath("//div[contains(@class, '-RichText')]//strong[contains(text(), 'Bedroom')]"));
            foreach(IWebElement webElement in webElements)
            {
                string size = webElement.Text;
                IWebElement featureWebElement = webElement.FindElement(By.XPath("//following-sibling::br/following-sibling::br"));
                string feature = featureWebElement.Text;
                roomSize.Add(new Rooms(size, feature));
            }
            return roomSize;
        }

        public string getStreetName()
        {
            IWebElement webElement = webDriver.FindElement(By.XPath("//span[@data-testid='address-label']"));
            string streetname = webElement.Text.Split(", ")[0];
            return streetname;
        }

        public void closeChrome()
        {
            webDriver.Close();
        }

    }
}

