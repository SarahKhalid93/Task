﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;

namespace UIAutomationTasks.UIAutomationTasks
{
    class Rooms
    {
        private String name;
        private String feature;

        public Rooms(String name, String feature )
        {
            this.name = name;
            this.feature = feature;
        }

        public String getName()
        {
            return name;
        }

        public String getFeature()
        {
            return feature;
        }
    }
}